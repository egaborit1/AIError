﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace AIErrors
{
    public partial class formName : Form
    {
        public formName()
        {
            InitializeComponent();
        }

        private void formName_Load(object sender, EventArgs e)
        {
            Timer1.Enabled = true;
            Timer1.Start();

        }

        
        private void Timer1_Tick_1(object sender, EventArgs e)
        {
            ProgressBar.Increment(3);
            if(ProgressBar.Value == 100) { 
                this.Visible = false;


                Timer1.Tick -= Timer1_Tick_1;
                           
                mainPage mainForm = new mainPage();
                mainForm.Closed += (s, args) => this.Close(); 
                mainForm.Show();
                /*mainPage mainForm = new mainPage();
                mainForm.Show();*/
            }
        }
    }
}
